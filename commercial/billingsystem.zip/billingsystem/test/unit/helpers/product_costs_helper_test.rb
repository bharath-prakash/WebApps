require 'test_helper'

class ProductCostsHelperTest < ActionView::TestCase
end
