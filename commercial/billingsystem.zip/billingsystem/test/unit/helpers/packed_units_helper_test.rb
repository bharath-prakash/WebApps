require 'test_helper'

class PackedUnitsHelperTest < ActionView::TestCase
end
