require 'test_helper'

class PackedUnitTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
