require 'test_helper'

class TaxMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
