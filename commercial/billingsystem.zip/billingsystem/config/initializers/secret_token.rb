# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Billingsystem::Application.config.secret_token = '0ddd5f893d8f3631c6483110b7d4106973b521fbd4c0cfeef13d8f7f561acc3d3f8c39d052eefe9409858d9b6f993160bc54115db5d00e572f47f5a82604c401'
